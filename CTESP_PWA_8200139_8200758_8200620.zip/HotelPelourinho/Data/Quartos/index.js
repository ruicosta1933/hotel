const Quartos = require('./quartos');
const QuartosService = require('./service');

const service = QuartosService(Quartos);

module.exports = service;