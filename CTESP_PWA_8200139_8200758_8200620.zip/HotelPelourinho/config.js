const config = {
    db : 'mongodb://localhost/hotel',
    secret: "superscret",
    expiresPassword : 86400,
    saltRounds: 10,
    MAIL_USER : "hoteldopelourinho@gmail.com",
    MAIL_PASS : "pelourinhoallez",
    MAIL_FROM : "hoteldopelourinho@gmail.com"
}

module.exports = config;